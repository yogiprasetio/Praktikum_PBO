package javathreads;
import java.util.Scanner;

public class JavaThreads {

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        Thread chrot;
        String nama;
        char ljt='Y';
        int id=0;
        do{
        System.out.println("===================== Program nyoba Threads iki ================");
        System.out.println("menu : ");
        System.out.println("1. Nekat coba");
        System.out.println("2. Mundur alon-alon");
        System.out.println("================================================================");
        System.out.print("pilihan : ");
        id=in.nextInt();
        if(id==1){
            System.out.print("Masukkan nama teman/kerabat/siapapun : ");
            nama=in.next();
            chrot=new Thread(new chreads(nama));
            chrot.start(); 
        }
        else if(id==2){
            System.out.print("bye.......");
            int sure = 0;
            System.exit(sure);
        }
           
    }
        while(ljt=='Y');
    }
}
