package javathreads;

/**
 *
 * @author yogi-06926
 */
class chreads implements Runnable{
    String nama;
    
    public chreads(String nama){
        this.nama=nama;
                
    }
     public void run(){
        for (int i=0;i<6;i++){
            try {
                Thread.currentThread().sleep(2000);
            } catch (InterruptedException ie) {
                System.out.println("\nTer-Execute");
            }
            System.out.println("\nThread " + nama +" "+(i+1)+ ": ada pada Posisi -> " + i);
        
        }
    }
    
   
}
